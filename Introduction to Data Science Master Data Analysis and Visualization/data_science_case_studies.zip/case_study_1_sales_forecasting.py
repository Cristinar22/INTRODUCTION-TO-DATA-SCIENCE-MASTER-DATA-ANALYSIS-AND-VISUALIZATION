
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA

# Load the dataset
df = pd.read_csv('sales_data.csv', parse_dates=['Date'], index_col='Date')

# Plot the sales data
df['Sales'].plot()
plt.title('Sales Data Over Time')
plt.xlabel('Date')
plt.ylabel('Sales')
plt.show()

# Train an ARIMA model
model = ARIMA(df['Sales'], order=(5,1,0))  # p, d, q
model_fit = model.fit()

# Make forecast
forecast = model_fit.forecast(steps=12)  # Predicting the next 12 months

# Plot the forecast
plt.plot(df.index, df['Sales'], label='Historical Data')
plt.plot(pd.date_range(df.index[-1], periods=12, freq='M'), forecast, label='Forecast', color='red')
plt.title('Sales Forecast')
plt.xlabel('Date')
plt.ylabel('Sales')
plt.legend()
plt.show()
