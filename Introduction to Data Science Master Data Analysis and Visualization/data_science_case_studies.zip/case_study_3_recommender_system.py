
from surprise import SVD, Dataset, Reader
from surprise.model_selection import train_test_split
from surprise import accuracy

# Load dataset
data = Dataset.load_builtin('ml-100k')  # MovieLens dataset

# Split the data into train and test
trainset, testset = train_test_split(data, test_size=0.2)

# Use SVD (Singular Value Decomposition) for collaborative filtering
model = SVD()
model.fit(trainset)

# Make predictions
predictions = model.test(testset)

# Evaluate the model
rmse = accuracy.rmse(predictions)
print(f"RMSE: {rmse}")
