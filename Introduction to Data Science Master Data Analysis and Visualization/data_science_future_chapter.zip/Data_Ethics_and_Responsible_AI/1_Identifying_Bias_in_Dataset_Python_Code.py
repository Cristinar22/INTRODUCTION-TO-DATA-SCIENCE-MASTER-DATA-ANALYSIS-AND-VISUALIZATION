
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load a sample dataset (e.g., Loan Prediction)
df = pd.read_csv('loan_data.csv')

# Preprocessing: Convert categorical variables to numerical
df['Gender'] = df['Gender'].map({'Male': 0, 'Female': 1})

# Features and target variable
X = df[['Gender', 'Age', 'Income']]
y = df['Loan_Approved']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model = LogisticRegression()
model.fit(X_train, y_train)

# Evaluate the model
y_pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))

# Check for gender bias
gender_bias = abs((y_pred[df['Gender'] == 1].mean()) - (y_pred[df['Gender'] == 0].mean()))
print(f"Gender Bias: {gender_bias}")
