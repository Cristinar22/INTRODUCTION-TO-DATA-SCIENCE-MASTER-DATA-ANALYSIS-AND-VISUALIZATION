# Example of data analysis with pandas
import pandas as pd
# Your data analysis code here