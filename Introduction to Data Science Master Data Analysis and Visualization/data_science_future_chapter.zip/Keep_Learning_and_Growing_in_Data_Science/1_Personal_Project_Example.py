# Example of a personal project to practice data science
# Your code here