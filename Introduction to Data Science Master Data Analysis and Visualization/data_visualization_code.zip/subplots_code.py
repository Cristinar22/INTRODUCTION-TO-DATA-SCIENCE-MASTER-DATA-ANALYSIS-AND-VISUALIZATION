import matplotlib.pyplot as plt

# Sample data
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
sales = [250, 300, 350, 400, 450, 500]
categories = ['T-Shirts', 'Jeans', 'Hats', 'Shoes']
category_sales = [120, 150, 90, 200]

# Create a figure with 1 row and 2 columns
fig, axes = plt.subplots(1, 2, figsize=(10, 5))

# Plot on the first subplot (Line Chart)
axes[0].plot(months, sales, color='blue')
axes[0].set_title('Sales Over Time')
axes[0].set_xlabel('Month')
axes[0].set_ylabel('Sales ($)')

# Plot on the second subplot (Bar Chart)
axes[1].bar(categories, category_sales, color='green')
axes[1].set_title('Sales by Category')
axes[1].set_xlabel('Category')
axes[1].set_ylabel('Sales ($)')

# Adjust layout for better spacing
plt.tight_layout()

# Show the plot
plt.show()
