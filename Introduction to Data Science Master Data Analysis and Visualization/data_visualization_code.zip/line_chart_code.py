import matplotlib.pyplot as plt

# Sample data: Sales over 6 months
months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
sales = [250, 300, 350, 400, 450, 500]

# Create a Line Chart
plt.plot(months, sales, marker='o', linestyle='-', color='b')

# Add titles and labels
plt.title('Sales Over Time')
plt.xlabel('Month')
plt.ylabel('Sales ($)')

# Show the chart
plt.show()
