import matplotlib.pyplot as plt

# Sample data: Advertising spend and sales
ad_spend = [10, 20, 30, 40, 50]
sales = [100, 200, 250, 300, 400]

# Create a Scatter Plot
plt.scatter(ad_spend, sales, color='red')

# Add titles and labels
plt.title('Advertising Spend vs Sales')
plt.xlabel('Advertising Spend ($)')
plt.ylabel('Sales ($)')

# Show the chart
plt.show()
