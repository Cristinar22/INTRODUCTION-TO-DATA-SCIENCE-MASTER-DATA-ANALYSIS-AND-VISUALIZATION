import matplotlib.pyplot as plt

# Sample data: Sales by product category
categories = ['T-Shirts', 'Jeans', 'Hats', 'Shoes']
sales = [120, 150, 90, 200]

# Create a Pie Chart
plt.pie(sales, labels=categories, autopct='%1.1f%%', startangle=90)

# Add a title
plt.title('Sales Distribution by Product Category')

# Show the chart
plt.show()
