import matplotlib.pyplot as plt

# Sample data: Sales for different product categories
categories = ['T-Shirts', 'Jeans', 'Hats', 'Shoes']
sales = [120, 150, 90, 200]

# Create a Bar Chart
plt.bar(categories, sales, color='orange')

# Add titles and labels
plt.title('Sales by Product Category')
plt.xlabel('Product Category')
plt.ylabel('Sales ($)')

# Show the chart
plt.show()
