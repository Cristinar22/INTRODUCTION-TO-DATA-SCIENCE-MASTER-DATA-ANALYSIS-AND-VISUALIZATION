from sklearn.preprocessing import LabelEncoder

# Example dataset with categorical data
data = {'Country': ['USA', 'Canada', 'Mexico', 'USA', 'Mexico']}
df = pd.DataFrame(data)

# Initialize LabelEncoder
labelencoder = LabelEncoder()

# Encode the 'Country' column
df['Country_encoded'] = labelencoder.fit_transform(df['Country'])

# Display the dataset after encoding
print(df)