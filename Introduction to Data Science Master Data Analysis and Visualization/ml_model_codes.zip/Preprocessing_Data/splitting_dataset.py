from sklearn.model_selection import train_test_split

# Example dataset
X = df[['Age', 'Income']]  # Features
y = [0, 1, 1, 0, 1]  # Labels (target variable)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Training features:
{X_train}")
print(f"Test features:
{X_test}")