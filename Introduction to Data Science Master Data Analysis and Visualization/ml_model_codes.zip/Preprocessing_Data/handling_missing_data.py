import pandas as pd

# Example dataset
data = {'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eve'],
        'Age': [25, None, 30, None, 22]}

df = pd.DataFrame(data)

# Fill missing values with the mean of the column
df['Age'].fillna(df['Age'].mean(), inplace=True)

# Display the dataset after handling missing data
print(df)