from sklearn.preprocessing import StandardScaler

# Example dataset
data = {'Age': [25, 30, 35, 40, 45], 'Income': [50000, 60000, 70000, 80000, 90000]}
df = pd.DataFrame(data)

# Initialize the scaler
scaler = StandardScaler()

# Scale the features
df_scaled = scaler.fit_transform(df)

# Display the scaled dataset
print(df_scaled)