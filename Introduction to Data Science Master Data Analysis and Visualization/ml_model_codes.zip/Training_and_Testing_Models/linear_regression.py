from sklearn.linear_model import LinearRegression

# Example data: Square footage and house prices
X_train = [[800], [1000], [1500], [2000], [2500]]
y_train = [200000, 250000, 300000, 350000, 400000]

# Initialize the model
model = LinearRegression()

# Train the model
model.fit(X_train, y_train)

# Predict house prices for new square footage values
new_data = [[1200], [1800]]
predictions = model.predict(new_data)

print(f"Predicted prices: {predictions}")