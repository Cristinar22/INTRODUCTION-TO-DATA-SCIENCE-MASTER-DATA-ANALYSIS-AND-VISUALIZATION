from sklearn.model_selection import cross_val_score

# Evaluate model using 5-fold cross-validation
scores = cross_val_score(model, X, y, cv=5)

print(f"Cross-Validation Scores: {scores}")
print(f"Mean Score: {scores.mean()}")