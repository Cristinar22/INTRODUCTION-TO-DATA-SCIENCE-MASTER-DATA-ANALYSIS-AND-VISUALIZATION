from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV

# Define a Decision Tree model
dt = DecisionTreeClassifier()

# Define a parameter grid for tuning
param_grid = {
    'max_depth': [3, 5, 7],
    'min_samples_split': [2, 5, 10]
}

# Perform grid search with cross-validation
grid_search = GridSearchCV(dt, param_grid, cv=5)

# Fit the grid search to the data
grid_search.fit(X_train, y_train)

# Print the best parameters
print(f"Best Parameters: {grid_search.best_params_}")