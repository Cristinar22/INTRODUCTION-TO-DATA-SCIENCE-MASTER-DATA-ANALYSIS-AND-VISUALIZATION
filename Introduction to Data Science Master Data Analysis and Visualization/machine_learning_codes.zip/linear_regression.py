
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# Example data: Square footage and house prices
data = {'Square_Feet': [800, 1000, 1500, 2000, 2500],
        'Price': [200000, 250000, 300000, 350000, 400000]}

# Create a DataFrame
df = pd.DataFrame(data)

# Define the feature (X) and target variable (y)
X = df[['Square_Feet']]  # Feature
y = df['Price']  # Target

# Initialize the model
model = LinearRegression()

# Fit the model to the data
model.fit(X, y)

# Predict house prices for new data
new_data = np.array([[1200], [1800]])  # New square footage values
predictions = model.predict(new_data)

# Display predictions
print(f"Predicted prices for 1200 and 1800 sq ft: {predictions}")

# Plot the data and regression line
plt.scatter(X, y, color='blue')  # Scatter plot of the original data
plt.plot(X, model.predict(X), color='red')  # Regression line
plt.title('Square Footage vs House Price')
plt.xlabel('Square Feet')
plt.ylabel('Price')
plt.show()
