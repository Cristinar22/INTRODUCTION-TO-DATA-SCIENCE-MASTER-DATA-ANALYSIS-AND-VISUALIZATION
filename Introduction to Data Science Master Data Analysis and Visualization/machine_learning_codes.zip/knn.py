
from sklearn.neighbors import KNeighborsClassifier
import numpy as np
import pandas as pd

# Example data: Age, Income, and Category (Low or High)
data = {'Age': [22, 25, 47, 52, 46],
        'Income': [30000, 40000, 60000, 80000, 65000],
        'Category': ['Low', 'Low', 'High', 'High', 'High']}

df = pd.DataFrame(data)

# Features and target
X = df[['Age', 'Income']]  # Features
y = df['Category']  # Target

# Initialize the K-NN model
knn = KNeighborsClassifier(n_neighbors=3)

# Train the model
knn.fit(X, y)

# Predict the category for a new data point
new_data = np.array([[30, 45000]])
prediction = knn.predict(new_data)

# Display the prediction
print(f"Predicted category: {prediction[0]}")
