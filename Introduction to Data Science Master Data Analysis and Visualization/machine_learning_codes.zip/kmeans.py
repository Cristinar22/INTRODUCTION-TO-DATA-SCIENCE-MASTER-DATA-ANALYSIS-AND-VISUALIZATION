
from sklearn.cluster import KMeans
import numpy as np
import pandas as pd

# Example data: Age and Income
data = {'Age': [22, 25, 47, 52, 46, 23, 35],
        'Income': [30000, 40000, 60000, 80000, 65000, 28000, 55000]}

df = pd.DataFrame(data)

# Features
X = df[['Age', 'Income']]

# Initialize the K-Means model with 2 clusters
kmeans = KMeans(n_clusters=2)

# Fit the model to the data
kmeans.fit(X)

# Predict the cluster for each data point
df['Cluster'] = kmeans.predict(X)

# Display the data with the assigned clusters
print(df)
