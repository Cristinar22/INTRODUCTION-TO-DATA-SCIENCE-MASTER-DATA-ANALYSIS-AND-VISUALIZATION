
import dask.dataframe as dd

# Load a large CSV file using Dask
df = dd.read_csv('large_data.csv')

# Perform a simple operation (filtering rows)
filtered_data = df[df['column_name'] > 100]

# Compute the result
filtered_data.compute()
    