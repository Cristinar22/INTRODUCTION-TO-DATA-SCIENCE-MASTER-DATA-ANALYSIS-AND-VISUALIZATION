
library(data.table)

# Load a large CSV file as a data.table
dt <- fread("large_data.csv")

# Perform a simple operation (filtering rows)
filtered_data <- dt[column_name > 100]

# View the result
head(filtered_data)
    