
# Example of Hadoop commands to move data to HDFS
hadoop fs -put localfile.txt /user/hadoop/input
hadoop jar wordcount.jar org.apache.hadoop.examples.WordCount /user/hadoop/input /user/hadoop/output
    