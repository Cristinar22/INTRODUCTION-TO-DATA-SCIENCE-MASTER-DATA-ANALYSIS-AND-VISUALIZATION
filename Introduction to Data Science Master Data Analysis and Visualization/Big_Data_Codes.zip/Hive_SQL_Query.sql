
SELECT user_id, COUNT(*) as purchase_count
FROM transactions
GROUP BY user_id
HAVING purchase_count > 5;
    