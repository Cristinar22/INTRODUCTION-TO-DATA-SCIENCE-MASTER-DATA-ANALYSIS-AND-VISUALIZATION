
from pyspark import SparkContext

# Initialize SparkContext
sc = SparkContext("local", "SimpleApp")

# Load a text file into an RDD (Resilient Distributed Dataset)
rdd = sc.textFile("hdfs://path/to/textfile.txt")

# Count the number of lines in the text file
line_count = rdd.count()

print(f"Number of lines: {line_count}")
    