
from kafka import KafkaConsumer

# Connect to Kafka
consumer = KafkaConsumer('sensor_data', bootstrap_servers=['localhost:9092'])

# Process incoming messages
for message in consumer:
    print(f"Received message: {message.value}")
    