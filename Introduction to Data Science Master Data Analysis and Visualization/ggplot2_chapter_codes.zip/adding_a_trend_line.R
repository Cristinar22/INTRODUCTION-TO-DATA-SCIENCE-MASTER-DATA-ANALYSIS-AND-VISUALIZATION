
# Scatter plot with a regression line
ggplot(mtcars, aes(x = mpg, y = hp)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE, color = "blue") +
  labs(title = "Scatter Plot with Regression Line", x = "Miles per Gallon (mpg)", y = "Horsepower (hp)") +
  theme_minimal()
