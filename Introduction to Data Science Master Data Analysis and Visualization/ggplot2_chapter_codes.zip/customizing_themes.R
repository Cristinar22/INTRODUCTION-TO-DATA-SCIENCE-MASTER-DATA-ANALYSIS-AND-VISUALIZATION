
# Predefined theme: Black and White
ggplot(mtcars, aes(x = mpg, y = hp)) +
  geom_point() +
  theme_bw() +
  labs(title = "Scatter Plot with Black and White Theme", x = "Miles per Gallon (mpg)", y = "Horsepower (hp)")
