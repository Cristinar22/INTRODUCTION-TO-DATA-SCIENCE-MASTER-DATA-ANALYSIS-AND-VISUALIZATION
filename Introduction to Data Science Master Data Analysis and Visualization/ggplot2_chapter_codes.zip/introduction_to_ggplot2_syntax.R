
# Basic Syntax of ggplot2
ggplot(data, aes(x = variable1, y = variable2)) +
  geom_type() +
  additional_layers()
