
# Faceting by number of cylinders
ggplot(mtcars, aes(x = mpg, y = hp)) +
  geom_point() +
  facet_wrap(~ cyl) +
  labs(title = "Scatter Plot of MPG vs HP by Number of Cylinders", x = "Miles per Gallon (mpg)", y = "Horsepower (hp)") +
  theme_minimal()
