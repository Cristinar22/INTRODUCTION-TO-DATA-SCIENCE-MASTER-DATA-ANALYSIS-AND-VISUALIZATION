
# Install ggplot2 (if not already installed)
install.packages("ggplot2")

# Load ggplot2 and the mtcars dataset
library(ggplot2)

# Load the mtcars dataset
data(mtcars)

# Create a scatter plot
ggplot(mtcars, aes(x = mpg, y = hp)) +
  geom_point()
