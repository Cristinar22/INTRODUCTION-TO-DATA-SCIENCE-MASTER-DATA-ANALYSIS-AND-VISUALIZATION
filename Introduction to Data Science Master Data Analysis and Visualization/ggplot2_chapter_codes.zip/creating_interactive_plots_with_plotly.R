
# Create an interactive plot using Plotly
install.packages("plotly")
library(plotly)

p <- ggplot(mtcars, aes(x = mpg, y = hp, color = factor(cyl))) +
  geom_point() +
  labs(title = "Interactive Scatter Plot of MPG vs HP")

# Convert to interactive plot
ggplotly(p)
