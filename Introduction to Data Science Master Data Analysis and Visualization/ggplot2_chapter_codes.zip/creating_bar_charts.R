
# Bar chart for average horsepower by number of cylinders
ggplot(mtcars, aes(x = factor(cyl), y = hp)) +
  geom_bar(stat = "summary", fun = "mean", fill = "lightblue", color = "black") +
  labs(title = "Average Horsepower by Number of Cylinders", x = "Number of Cylinders", y = "Average Horsepower") +
  theme_minimal()
