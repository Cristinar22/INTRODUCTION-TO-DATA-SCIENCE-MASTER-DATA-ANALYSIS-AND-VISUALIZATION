
# Scatter plot with color and size customizations
ggplot(mtcars, aes(x = mpg, y = hp, color = factor(cyl), size = wt)) +
  geom_point() +
  labs(title = "Scatter Plot of MPG vs HP", x = "Miles per Gallon (mpg)", y = "Horsepower (hp)") +
  theme_minimal()
