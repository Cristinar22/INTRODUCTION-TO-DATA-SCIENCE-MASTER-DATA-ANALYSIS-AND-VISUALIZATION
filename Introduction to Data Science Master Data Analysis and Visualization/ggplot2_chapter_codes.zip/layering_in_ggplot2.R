
# Layered plot with scatter, regression line, and bar chart
ggplot(mtcars, aes(x = mpg, y = hp)) +
  geom_point(aes(color = factor(cyl)), size = 3) +
  geom_smooth(method = "lm", se = FALSE, color = "black") +
  geom_bar(stat = "summary", fun = "mean", fill = "skyblue", color = "black", alpha = 0.5) +
  facet_wrap(~ cyl) +
  labs(title = "Layered Plot: MPG vs HP with Regression Line and Bar Chart", x = "Miles per Gallon (mpg)", y = "Horsepower (hp)") +
  theme_minimal()
