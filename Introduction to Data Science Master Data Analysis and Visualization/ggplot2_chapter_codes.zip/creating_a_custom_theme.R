
# Custom theme with modified axis and title
custom_theme <- theme(
  axis.text.x = element_text(angle = 45, hjust = 1),
  axis.text.y = element_text(color = "blue"),
  plot.title = element_text(hjust = 0.5, size = 16)
)

ggplot(mtcars, aes(x = mpg, y = hp)) +
  geom_point() +
  custom_theme +
  labs(title = "Custom Themed Scatter Plot", x = "Miles per Gallon (mpg)", y = "Horsepower (hp)")
