from scipy.stats import zscore
# Calculate the Z-scores for the data
z_scores = zscore(data[['Price', 'Quantity']])
# Find rows with Z-scores greater than 3 or less than -3
outliers = data[(z_scores > 3) | (z_scores < -3)]
print(outliers)
# Remove outliers
data_no_outliers = data[(z_scores <= 3) & (z_scores >= -3)]
# Display the data without outliers
print(data_no_outliers.head())