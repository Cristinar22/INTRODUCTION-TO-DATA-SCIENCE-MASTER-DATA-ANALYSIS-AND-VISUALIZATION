import requests
import pandas as pd
# Make a GET request to an API
response = requests.get('https://api.example.com/data')
# Convert the response to JSON
data_json = response.json()
# Convert the JSON data to a Pandas DataFrame
data = pd.DataFrame(data_json)
# Display the first few rows of the data
print(data.head())