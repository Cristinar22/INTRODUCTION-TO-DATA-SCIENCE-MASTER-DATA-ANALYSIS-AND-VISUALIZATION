from sklearn.preprocessing import StandardScaler
# Create a StandardScaler object
scaler = StandardScaler()
# Fit the scaler to the data and transform the data
data_scaled = scaler.fit_transform(data[['Price', 'Quantity']])
# Display the transformed data
print(data_scaled)
# Convert categorical data into numeric using one-hot encoding
data_encoded = pd.get_dummies(data, columns=['Category'])
# Display the encoded data
print(data_encoded.head())