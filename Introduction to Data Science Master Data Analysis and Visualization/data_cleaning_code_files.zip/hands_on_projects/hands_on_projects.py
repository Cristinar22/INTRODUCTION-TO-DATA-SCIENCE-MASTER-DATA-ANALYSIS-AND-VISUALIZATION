# Python Project: Importing and Cleaning Data
import pandas as pd
# 1. Download a CSV file containing sales data.
data = pd.read_csv('sales_data.csv')
# 2. Import the data into a Pandas DataFrame.
# 3. Check for missing values and handle them appropriately.
print(data.isnull().sum())
# 4. Clean the data by removing outliers using Z-scores.
from scipy.stats import zscore
z_scores = zscore(data[['Price', 'Quantity']])
data_no_outliers = data[(z_scores <= 3) & (z_scores >= -3)]
print(data_no_outliers.head())