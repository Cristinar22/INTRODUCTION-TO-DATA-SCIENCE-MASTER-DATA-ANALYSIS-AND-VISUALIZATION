# Check for missing values in the data
print(data.isnull().sum())
# Remove rows with missing values
data_cleaned = data.dropna()
# Display the cleaned data
print(data_cleaned.head())
# Fill missing values with the mean
data_filled = data.fillna(data.mean())
# Display the data with filled values
print(data_filled.head())