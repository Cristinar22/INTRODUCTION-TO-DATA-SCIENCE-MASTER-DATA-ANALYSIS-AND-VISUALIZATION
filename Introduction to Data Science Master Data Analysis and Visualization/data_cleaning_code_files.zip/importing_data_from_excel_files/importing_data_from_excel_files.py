import pandas as pd
# Importing data from an Excel file
data = pd.read_excel('sales_data.xlsx')
# Display the first few rows of the dataset
print(data.head())