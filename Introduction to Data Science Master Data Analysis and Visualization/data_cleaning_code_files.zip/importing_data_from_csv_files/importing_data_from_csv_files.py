import pandas as pd
# Importing data from a CSV file
data = pd.read_csv('sales_data.csv')
# Display the first few rows of the dataset
print(data.head())