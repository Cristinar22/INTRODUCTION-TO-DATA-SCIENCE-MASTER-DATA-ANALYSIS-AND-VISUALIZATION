# R Project (RStudio)
library(ggplot2)
library(dplyr)

# Load the dataset
df <- read.csv('sales_data.csv')

# Filter data using dplyr
df_filtered <- df %>% filter(Sales > 100)

# Create a scatter plot showing sales vs. product categories
ggplot(df_filtered, aes(x = Product, y = Sales)) +
    geom_point() +
    labs(title = 'Sales vs Product Categories', x = 'Product', y = 'Sales')