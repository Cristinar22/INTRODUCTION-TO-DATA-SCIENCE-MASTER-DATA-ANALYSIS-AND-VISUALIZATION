# Python Project (Jupyter Notebooks)
import pandas as pd

# Load the dataset
df = pd.read_csv('sales_data.csv')

# Clean the data by handling missing values and checking for duplicates
df.fillna(0, inplace=True)
df.drop_duplicates(inplace=True)

# Visualize sales trends using Matplotlib
import matplotlib.pyplot as plt
plt.plot(df['Date'], df['Sales'])
plt.xlabel('Date')
plt.ylabel('Sales')
plt.title('Sales Trends')
plt.show()