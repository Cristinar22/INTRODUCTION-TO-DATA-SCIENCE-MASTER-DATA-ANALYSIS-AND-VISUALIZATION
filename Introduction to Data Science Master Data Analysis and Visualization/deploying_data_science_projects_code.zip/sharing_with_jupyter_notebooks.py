
# Code for Jupyter Notebook
import pandas as pd
import matplotlib.pyplot as plt

# Loading a dataset
data = pd.read_csv('data.csv')

# Simple plot
plt.plot(data['Date'], data['Sales'])
plt.title('Sales Over Time')
plt.xlabel('Date')
plt.ylabel('Sales')
plt.show()
    