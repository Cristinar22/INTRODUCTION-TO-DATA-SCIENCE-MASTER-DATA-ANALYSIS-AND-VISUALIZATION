
---
title: "Sales Analysis"
author: "Your Name"
output: html_document
---

## Introduction

This is an analysis of sales data over time.

```{r}
# Load data
data <- read.csv('sales.csv')

# Plot sales over time
plot(data$Date, data$Sales, type = 'l', main = 'Sales Over Time', xlab = 'Date', ylab = 'Sales')
```
    