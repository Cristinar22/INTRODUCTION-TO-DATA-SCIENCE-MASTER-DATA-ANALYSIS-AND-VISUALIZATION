
# Install Flask
# bash
# pip install Flask

from flask import Flask, request, jsonify
import pandas as pd
from sklearn.linear_model import LogisticRegression

# Initialize Flask app
app = Flask(__name__)

# Train a model (for simplicity, using a simple logistic regression model)
data = pd.read_csv('iris.csv')
X = data[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']]
y = data['species']
model = LogisticRegression()
model.fit(X, y)

# Define route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Get data from the request
    data = request.get_json()
    features = [data['sepal_length'], data['sepal_width'], data['petal_length'], data['petal_width']]
    
    # Make prediction
    prediction = model.predict([features])
    
    return jsonify({'prediction': prediction[0]})

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
    