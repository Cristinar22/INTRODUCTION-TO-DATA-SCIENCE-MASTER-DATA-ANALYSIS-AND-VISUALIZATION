
# Install Shiny
# R
# install.packages("shiny")

library(shiny)

# Load model
model <- readRDS("logistic_model.rds")

# Define UI
ui <- fluidPage(
  titlePanel("Iris Species Prediction"),
  sidebarLayout(
    sidebarPanel(
      numericInput("sepal_length", "Sepal Length:", 5),
      numericInput("sepal_width", "Sepal Width:", 3),
      numericInput("petal_length", "Petal Length:", 4),
      numericInput("petal_width", "Petal Width:", 1.5),
      actionButton("predict", "Predict")
    ),
    mainPanel(
      textOutput("prediction")
    )
  )
)

# Define server logic
server <- function(input, output) {
  observeEvent(input$predict, {
    # Get input values
    new_data <- data.frame(
      sepal_length = input$sepal_length,
      sepal_width = input$sepal_width,
      petal_length = input$petal_length,
      petal_width = input$petal_width
    )
    
    # Make prediction
    prediction <- predict(model, new_data)
    
    # Display the prediction
    output$prediction <- renderText({ paste("Predicted Species: ", prediction) })
  })
}

# Run the app
shinyApp(ui = ui, server = server)
    