
# Initialize a Git repository
git init

# Add files and commit
git add .
git commit -m "Initial commit"

# Push changes to GitHub
git remote add origin <url>
git push -u origin master
    