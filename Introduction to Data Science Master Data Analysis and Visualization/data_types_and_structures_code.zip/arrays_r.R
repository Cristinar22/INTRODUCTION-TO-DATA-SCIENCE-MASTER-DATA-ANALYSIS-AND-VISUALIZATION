
# Creating a 1D array
arr <- c(1, 2, 3, 4, 5)
print(arr)

# Creating a 2D array (matrix)
matrix <- array(1:6, dim = c(3, 2))
print(matrix)
