
# Creating a list
clothing_items = ["T-Shirt", "Jeans", "Hat", "Shoes"]
print(clothing_items)

# Accessing elements by index
print(clothing_items[0])  # Output: T-Shirt

# Modifying an element
clothing_items[1] = "Sweater"
print(clothing_items)
