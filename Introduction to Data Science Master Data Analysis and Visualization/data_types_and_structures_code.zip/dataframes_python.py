
import pandas as pd

# Creating a DataFrame
data = {
    "Item": ["T-Shirt", "Jeans", "Hat", "Shoes"],
    "Price": [19.99, 49.99, 9.99, 59.99],
    "On Sale": [True, False, True, False]
}

df = pd.DataFrame(data)

# Displaying the DataFrame
print(df)

# Accessing a column
print(df["Item"])

# Filtering data
sale_items = df[df["On Sale"] == True]
print(sale_items)
