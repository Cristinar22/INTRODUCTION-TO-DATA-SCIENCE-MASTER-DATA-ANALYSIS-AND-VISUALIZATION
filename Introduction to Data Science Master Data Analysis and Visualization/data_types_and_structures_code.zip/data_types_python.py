
# Integer
item_count = 15

# Float
item_price = 19.99

# String
item_name = "T-Shirt"

# Boolean
on_sale = True

# Printing the data types
print(type(item_count))  # <class 'int'>
print(type(item_price))  # <class 'float'>
print(type(item_name))  # <class 'str'>
print(type(on_sale))  # <class 'bool'>
