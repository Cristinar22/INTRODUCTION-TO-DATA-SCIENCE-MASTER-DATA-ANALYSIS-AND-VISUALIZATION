
# Creating a vector
clothing_items <- c("T-Shirt", "Jeans", "Hat", "Shoes")
print(clothing_items)

# Accessing elements by index
print(clothing_items[1])  # Output: T-Shirt

# Modifying an element
clothing_items[2] <- "Sweater"
print(clothing_items)
