
# Integer
item_count <- 15

# Float
item_price <- 19.99

# String
item_name <- "T-Shirt"

# Boolean
on_sale <- TRUE

# Printing the data types
print(class(item_count))  # "numeric"
print(class(item_price))  # "numeric"
print(class(item_name))   # "character"
print(class(on_sale))     # "logical"
