
# Creating a data frame
clothing_data <- data.frame(
    Item = c("T-Shirt", "Jeans", "Hat", "Shoes"),
    Price = c(19.99, 49.99, 9.99, 59.99),
    On_Sale = c(TRUE, FALSE, TRUE, FALSE)
)

# Displaying the data frame
print(clothing_data)

# Accessing a column
print(clothing_data$Item)

# Filtering data
sale_items <- subset(clothing_data, On_Sale == TRUE)
print(sale_items)
