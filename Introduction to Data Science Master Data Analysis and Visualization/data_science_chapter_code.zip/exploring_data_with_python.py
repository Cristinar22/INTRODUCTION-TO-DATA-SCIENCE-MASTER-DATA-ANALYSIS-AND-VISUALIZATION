
import pandas as pd

# Load a CSV file with sales data
df = pd.read_csv('sales_data.csv')

# Clean the data: remove missing values
df = df.dropna()

# Calculate basic statistics
mean_sales = df['Sales'].mean()
median_sales = df['Sales'].median()
mode_sales = df['Sales'].mode()

# Display the basic statistics
print('Mean:', mean_sales)
print('Median:', median_sales)
print('Mode:', mode_sales)
