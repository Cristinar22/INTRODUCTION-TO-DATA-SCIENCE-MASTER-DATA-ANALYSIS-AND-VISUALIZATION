
import pandas as pd
import matplotlib.pyplot as plt

# Sample data for sales in a week
data = {'Day': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
        'Sales': [200, 150, 300, 250, 400]}

# Create a DataFrame
df = pd.DataFrame(data)

# Plot the data
df.plot(x='Day', y='Sales', kind='bar')
plt.show()
