
# Import necessary libraries
library(ggplot2)

# Load a dataset
data <- read.csv('sales_data.csv')

# Create a scatter plot
ggplot(data, aes(x=Price, y=Sales)) +
  geom_point() +
  labs(title='Price vs Sales', x='Price', y='Sales')
