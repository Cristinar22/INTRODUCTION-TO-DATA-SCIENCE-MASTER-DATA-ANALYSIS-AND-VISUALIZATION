import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

# Generate a sample of 1000 random data points with a normal distribution
data = np.random.normal(loc=50, scale=10, size=1000)

# Create a histogram
plt.hist(data, bins=30, density=True, color='skyblue', edgecolor='black')

# Plot the normal distribution curve
xmin, xmax = plt.xlim()
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, np.mean(data), np.std(data))
plt.plot(x, p, 'k', linewidth=2)

# Add titles and labels
plt.title('Normal Distribution')
plt.xlabel('Value')
plt.ylabel('Frequency')
plt.show()