import pandas as pd
import matplotlib.pyplot as plt

# Example dataset: Test scores of 10 students
data = {'Student': ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'],
        'Score': [87, 90, 78, 85, 92, 88, 76, 95, 89, 84]}

df = pd.DataFrame(data)

# Calculate basic descriptive statistics
mean_score = df['Score'].mean()
median_score = df['Score'].median()
mode_score = df['Score'].mode()[0]
std_deviation = df['Score'].std()

# Display results
print(f"Mean: {mean_score}, Median: {median_score}, Mode: {mode_score}, Standard Deviation: {std_deviation}")

# Create a histogram to visualize the scores
plt.hist(df['Score'], bins=5, color='skyblue', edgecolor='black')
plt.title('Distribution of Test Scores')
plt.xlabel('Score')
plt.ylabel('Frequency')
plt.show()