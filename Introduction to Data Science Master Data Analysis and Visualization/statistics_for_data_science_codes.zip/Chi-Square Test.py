from scipy import stats
import numpy as np

# Example data: Survey responses (Yes or No)
observed = np.array([[30, 10], [15, 25]])

# Perform Chi-Square Test
chi2_stat, p_val, dof, expected = stats.chi2_contingency(observed)

# Display the results
print(f"Chi2-statistic: {chi2_stat}, P-value: {p_val}")