from scipy import stats
import numpy as np

# Sample data: Test scores for two groups
group1 = np.random.normal(75, 10, 50)
group2 = np.random.normal(80, 10, 50)

# Perform a two-sample T-test
t_stat, p_value = stats.ttest_ind(group1, group2)

# Display the results
print(f"T-statistic: {t_stat}, P-value: {p_value}")