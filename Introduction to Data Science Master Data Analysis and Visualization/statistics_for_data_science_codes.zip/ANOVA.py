from scipy import stats
import numpy as np

# Sample data: Scores from three different classes
group1 = np.random.normal(75, 10, 30)
group2 = np.random.normal(80, 10, 30)
group3 = np.random.normal(85, 10, 30)

# Perform one-way ANOVA
f_stat, p_value = stats.f_oneway(group1, group2, group3)

# Display the results
print(f"F-statistic: {f_stat}, P-value: {p_value}")