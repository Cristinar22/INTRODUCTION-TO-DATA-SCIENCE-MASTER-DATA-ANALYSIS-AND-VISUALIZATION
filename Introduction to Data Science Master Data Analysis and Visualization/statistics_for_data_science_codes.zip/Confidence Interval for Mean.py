from scipy import stats
import numpy as np

# Sample data for group1
group1 = np.random.normal(75, 10, 50)

# Calculate the confidence interval for the mean of group1
conf_interval = stats.t.interval(0.95, len(group1)-1, loc=np.mean(group1), scale=stats.sem(group1))

print(f"95% Confidence Interval: {conf_interval}")