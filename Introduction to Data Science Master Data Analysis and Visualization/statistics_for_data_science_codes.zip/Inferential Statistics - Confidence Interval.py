import scipy.stats as stats
import numpy as np

# Sample data (100 test scores)
sample_data = np.random.normal(loc=85, scale=10, size=100)

# Calculate sample mean and standard deviation
sample_mean = np.mean(sample_data)
sample_std = np.std(sample_data, ddof=1)

# Define the confidence level (95%)
confidence_level = 0.95

# Calculate the margin of error
confidence_interval = stats.t.interval(confidence_level, len(sample_data)-1, loc=sample_mean, scale=sample_std/np.sqrt(len(sample_data)))

# Display the confidence interval
print(f"Confidence Interval: {confidence_interval}")