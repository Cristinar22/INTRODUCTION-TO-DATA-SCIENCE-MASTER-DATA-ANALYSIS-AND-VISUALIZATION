# Create a population of 1000 values
population = np.random.normal(loc=50, scale=10, size=1000)

# Take a random sample of 100 values
sample = np.random.choice(population, size=100, replace=False)

# Display the sample
print(sample[:10])  # Display the first 10 values of the sample