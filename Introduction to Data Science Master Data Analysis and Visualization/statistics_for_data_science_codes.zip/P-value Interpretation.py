from scipy import stats
import numpy as np

# Sample data for two groups
group1 = np.random.normal(75, 10, 50)
group2 = np.random.normal(80, 10, 50)

# Perform T-test and print the result
t_stat, p_value = stats.ttest_ind(group1, group2)

if p_value < 0.05:
    print("Reject the null hypothesis. There is a significant difference between the groups.")
else:
    print("Fail to reject the null hypothesis. There is no significant difference between the groups.")