
install.packages("pheatmap")
library(pheatmap)

# Calculate the correlation matrix
corr_matrix <- cor(data[,2:3])

# Create a heatmap
pheatmap(corr_matrix, main = 'Heatmap of Correlation Matrix')
