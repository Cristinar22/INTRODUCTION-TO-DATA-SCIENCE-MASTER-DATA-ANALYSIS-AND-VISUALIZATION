
import pandas as pd

# Example sales data
data = {
    'Item': ['T-shirt', 'Jeans', 'Hat', 'Shoes', 'Sweater'],
    'Price': [19.99, 49.99, 9.99, 59.99, 29.99],
    'Quantity Sold': [120, 200, 150, 80, 140]
}

# Create a DataFrame
df = pd.DataFrame(data)

# Display the DataFrame
print(df)

# Calculate descriptive statistics
summary = df.describe()

# Display summary statistics
print(summary)
