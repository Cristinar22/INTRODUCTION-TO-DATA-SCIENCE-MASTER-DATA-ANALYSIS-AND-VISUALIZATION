
import seaborn as sns

# Create a box plot of 'Price' column
sns.boxplot(x=df['Price'])

# Add title
plt.title('Box Plot of Prices')

# Display the plot
plt.show()
