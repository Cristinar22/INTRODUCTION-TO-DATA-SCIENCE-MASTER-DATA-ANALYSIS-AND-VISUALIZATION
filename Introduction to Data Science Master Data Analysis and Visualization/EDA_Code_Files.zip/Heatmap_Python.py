
# Create a correlation matrix
corr_matrix = df.corr()

# Generate a heatmap
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm')

# Add title
plt.title('Heatmap of Correlation Matrix')

# Display the plot
plt.show()
