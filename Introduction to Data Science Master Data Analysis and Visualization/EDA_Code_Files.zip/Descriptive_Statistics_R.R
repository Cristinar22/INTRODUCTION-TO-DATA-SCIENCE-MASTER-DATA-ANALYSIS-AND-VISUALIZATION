
# Example sales data
data <- data.frame(
  Item = c('T-shirt', 'Jeans', 'Hat', 'Shoes', 'Sweater'),
  Price = c(19.99, 49.99, 9.99, 59.99, 29.99),
  Quantity_Sold = c(120, 200, 150, 80, 140)
)

# Calculate summary statistics
summary(data)
