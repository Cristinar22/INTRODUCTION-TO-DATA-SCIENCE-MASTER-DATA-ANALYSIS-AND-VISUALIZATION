
# Create a box plot of the 'Price' column
boxplot(data$Price, main = 'Box Plot of Prices', xlab = 'Price')
