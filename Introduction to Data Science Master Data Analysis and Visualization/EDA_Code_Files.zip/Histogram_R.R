
# Create a histogram of the 'Price' column
hist(data$Price, breaks = 5, col = 'skyblue', main = 'Histogram of Prices', xlab = 'Price')
