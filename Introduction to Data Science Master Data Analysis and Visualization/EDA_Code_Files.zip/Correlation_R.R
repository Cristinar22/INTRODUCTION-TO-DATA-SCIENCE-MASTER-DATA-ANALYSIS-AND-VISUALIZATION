
# Calculate the correlation matrix
corr_matrix <- cor(data[,2:3])

# Display the correlation matrix
print(corr_matrix)
