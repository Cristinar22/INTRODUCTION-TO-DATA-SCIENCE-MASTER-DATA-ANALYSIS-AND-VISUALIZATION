
import matplotlib.pyplot as plt

# Create a histogram of the 'Price' column
plt.hist(df['Price'], bins=5, color='skyblue', edgecolor='black')

# Add labels and title
plt.xlabel('Price')
plt.ylabel('Frequency')
plt.title('Histogram of Prices')

# Display the plot
plt.show()
