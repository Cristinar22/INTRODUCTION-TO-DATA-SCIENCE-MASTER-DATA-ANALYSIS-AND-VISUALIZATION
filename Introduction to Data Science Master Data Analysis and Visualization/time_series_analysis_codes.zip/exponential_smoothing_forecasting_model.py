
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import pandas as pd
import matplotlib.pyplot as plt

# Example: Monthly sales data for a year
data = {'Date': pd.date_range(start='1/1/2021', periods=12, freq='M'),
        'Sales': [250, 280, 320, 350, 400, 430, 460, 490, 530, 550, 600, 650]}

df = pd.DataFrame(data)

# Set the 'Date' column as the index
df.set_index('Date', inplace=True)

# Apply Exponential Smoothing to the sales data
model = ExponentialSmoothing(df['Sales'], trend='add', seasonal='add', seasonal_periods=12)
model_fit = model.fit()

# Forecast the next 3 months
forecast = model_fit.forecast(steps=3)
print(f"Forecasted sales for the next 3 months: {forecast}")

# Plotting the forecast
plt.plot(df.index, df['Sales'], label='Original Data')
forecast_index = pd.date_range(start='1/1/2022', periods=3, freq='M')
plt.plot(forecast_index, forecast, label='Forecast', linestyle='--')
plt.legend()
plt.show()
