
import pandas as pd
import matplotlib.pyplot as plt

# Example of Time Series Data: Daily visitors to a website
data = {'Date': pd.date_range(start='1/1/2021', periods=12, freq='M'),
        'Visitors': [250, 280, 320, 350, 400, 430, 460, 490, 530, 550, 600, 650]}

df = pd.DataFrame(data)

# Set the 'Date' column as the index
df.set_index('Date', inplace=True)

# Plotting the Time Series Data
plt.plot(df.index, df['Visitors'], marker='o')
plt.title('Visitors over Time')
plt.xlabel('Date')
plt.ylabel('Number of Visitors')
plt.grid(True)
plt.show()
