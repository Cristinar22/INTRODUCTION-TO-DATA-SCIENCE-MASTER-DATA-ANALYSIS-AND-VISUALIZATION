
import pandas as pd
from pmdarima import auto_arima
import matplotlib.pyplot as plt

# Example: Monthly sales data for a year
data = {'Date': pd.date_range(start='1/1/2021', periods=12, freq='M'),
        'Sales': [250, 280, 320, 350, 400, 430, 460, 490, 530, 550, 600, 650]}

df = pd.DataFrame(data)

# Set the 'Date' column as the index
df.set_index('Date', inplace=True)

# Fit an ARIMA model to the data
model = auto_arima(df['Sales'], seasonal=True, m=12)

# Make a forecast for the next 3 months
forecast = model.predict(n_periods=3)

# Display the forecast
print(f"Forecasted sales for the next 3 months: {forecast}")

# Plot the original data and the forecast
plt.plot(df.index, df['Sales'], label='Original Data')
forecast_index = pd.date_range(start='1/1/2022', periods=3, freq='M')
plt.plot(forecast_index, forecast, label='Forecast', linestyle='--')
plt.legend()
plt.show()
