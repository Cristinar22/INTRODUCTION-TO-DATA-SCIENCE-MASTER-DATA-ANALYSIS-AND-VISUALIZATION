
from sklearn.metrics import mean_absolute_error, mean_squared_error, mean_absolute_percentage_error

# Actual sales data for the next 3 months
actual_sales = [670, 700, 720]

# Example: Forecasted sales from the ARIMA or Exponential Smoothing Model
forecast = [660, 690, 710]

# Calculate MAE, MSE, and MAPE
mae = mean_absolute_error(actual_sales, forecast)
mse = mean_squared_error(actual_sales, forecast)
mape = mean_absolute_percentage_error(actual_sales, forecast)

print(f"Mean Absolute Error (MAE): {mae}")
print(f"Mean Squared Error (MSE): {mse}")
print(f"Mean Absolute Percentage Error (MAPE): {mape}")
