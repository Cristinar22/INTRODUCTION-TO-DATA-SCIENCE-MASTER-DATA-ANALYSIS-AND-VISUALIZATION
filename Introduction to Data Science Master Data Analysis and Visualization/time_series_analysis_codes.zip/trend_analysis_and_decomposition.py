
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.trend import seasonal_decompose

# Example: Monthly sales data for a year
data = {'Date': pd.date_range(start='1/1/2021', periods=12, freq='M'),
        'Sales': [250, 280, 320, 350, 400, 430, 460, 490, 530, 550, 600, 650]}

df = pd.DataFrame(data)

# Set the 'Date' column as the index
df.set_index('Date', inplace=True)

# Decompose the time series data into trend, seasonal, and residual components
result = seasonal_decompose(df['Sales'], model='additive', period=12)

# Plot the decomposition
result.plot()
plt.show()
